-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : acmsys
-- 
-- Part : #1
-- Date : 2017-05-25 18:56:47
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `acm_admin`
-- -----------------------------
DROP TABLE IF EXISTS `acm_admin`;
CREATE TABLE `acm_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `password_md5` varchar(40) DEFAULT NULL,
  `nickname` varchar(20) NOT NULL,
  `signUpTime` datetime DEFAULT NULL,
  `lastLoginTime` datetime DEFAULT NULL,
  `phoneNumber` varchar(45) DEFAULT '空',
  `email` varchar(50) DEFAULT '空',
  `position` varchar(45) DEFAULT '空',
  `tecentNumber` varchar(45) DEFAULT '空',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_admin`
-- -----------------------------
INSERT INTO `acm_admin` VALUES ('1', 'admin1', '123456', '202cb962ac59075b964b07152d234b70', '张三', '2017-03-10 00:00:00', '2017-05-25 02:02:52', '10000', 'admin@qq.com', '老师', '10000');
INSERT INTO `acm_admin` VALUES ('15', 'admin3', '123456', 'e10adc3949ba59abbe56e057f20f883e', '张三', '2017-05-12 20:53:27', '2017-05-12 20:53:27', '10000', 'admin@qq.com', '老师', '10000');
INSERT INTO `acm_admin` VALUES ('16', 'admin4', '123456', 'e10adc3949ba59abbe56e057f20f883e', '张三', '2017-05-12 20:53:38', '2017-05-12 20:53:38', '10000', 'admin@qq.com', '老师', '10000');

-- -----------------------------
-- Table structure for `acm_check_clazz`
-- -----------------------------
DROP TABLE IF EXISTS `acm_check_clazz`;
CREATE TABLE `acm_check_clazz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_clazz` int(11) NOT NULL,
  `id_stu` int(11) NOT NULL,
  `checktime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stu_idx` (`id_stu`),
  KEY `clazz_idx` (`id_clazz`),
  CONSTRAINT `clazz` FOREIGN KEY (`id_clazz`) REFERENCES `acm_clazz` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `stu` FOREIGN KEY (`id_stu`) REFERENCES `acm_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_check_clazz`
-- -----------------------------
INSERT INTO `acm_check_clazz` VALUES ('3', '1', '3', '2017-01-01 00:00:00');

-- -----------------------------
-- Table structure for `acm_clazz`
-- -----------------------------
DROP TABLE IF EXISTS `acm_clazz`;
CREATE TABLE `acm_clazz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clazzname` varchar(45) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `tutor` int(11) DEFAULT NULL,
  `last_time_modify` datetime DEFAULT NULL,
  `clazz_info` varchar(255) DEFAULT NULL,
  `grade` int(11) DEFAULT NULL,
  `level` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_clazz`
-- -----------------------------
INSERT INTO `acm_clazz` VALUES ('1', '班级1', '2017-05-20 00:00:00', '1', '2017-05-20 00:00:00', '班级', '2017', '2');
INSERT INTO `acm_clazz` VALUES ('2', '班级2', '2017-05-19 00:00:00', '2', '2017-05-19 00:00:00', '班级2', '2017', '1');

-- -----------------------------
-- Table structure for `acm_clazz_work`
-- -----------------------------
DROP TABLE IF EXISTS `acm_clazz_work`;
CREATE TABLE `acm_clazz_work` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `workcontent` varchar(45) DEFAULT '空',
  `createtime` datetime DEFAULT NULL,
  `clazz_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_clazz_work`
-- -----------------------------
INSERT INTO `acm_clazz_work` VALUES ('1', '这是班级事务', '2017-05-16 14:38:48', '1');
INSERT INTO `acm_clazz_work` VALUES ('4', '这是班级事务', '2017-05-16 14:50:02', '2');

-- -----------------------------
-- Table structure for `acm_inform`
-- -----------------------------
DROP TABLE IF EXISTS `acm_inform`;
CREATE TABLE `acm_inform` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL DEFAULT '空',
  `datetime` datetime NOT NULL,
  `content` varchar(45) NOT NULL DEFAULT '暂时无通知',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_inform`
-- -----------------------------
INSERT INTO `acm_inform` VALUES ('1', '关于申请班级事项', '2017-03-22 00:22:33', '通过注册审核后，请尽快申请加入班级');

-- -----------------------------
-- Table structure for `acm_todaylogin`
-- -----------------------------
DROP TABLE IF EXISTS `acm_todaylogin`;
CREATE TABLE `acm_todaylogin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_todaylogin`
-- -----------------------------
INSERT INTO `acm_todaylogin` VALUES ('3', '2017-05-15 20:48:54');
INSERT INTO `acm_todaylogin` VALUES ('4', '2017-05-16 17:36:09');
INSERT INTO `acm_todaylogin` VALUES ('5', '2017-05-16 17:53:23');
INSERT INTO `acm_todaylogin` VALUES ('6', '2017-05-19 02:37:49');
INSERT INTO `acm_todaylogin` VALUES ('7', '2017-05-19 14:25:51');
INSERT INTO `acm_todaylogin` VALUES ('8', '2017-05-19 15:52:00');
INSERT INTO `acm_todaylogin` VALUES ('9', '2017-05-20 01:25:17');
INSERT INTO `acm_todaylogin` VALUES ('10', '2017-05-22 03:13:58');

-- -----------------------------
-- Table structure for `acm_user`
-- -----------------------------
DROP TABLE IF EXISTS `acm_user`;
CREATE TABLE `acm_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(18) NOT NULL,
  `password` varchar(20) NOT NULL,
  `md5pwd` varchar(45) DEFAULT NULL,
  `nickname` varchar(20) NOT NULL,
  `sign_up_time` datetime DEFAULT NULL,
  `last_login_time` datetime DEFAULT NULL,
  `phonenumber` varchar(11) DEFAULT NULL,
  `institude` varchar(10) DEFAULT NULL,
  `class` varchar(15) DEFAULT NULL,
  `grade` int(3) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `stu_id` varchar(12) NOT NULL,
  `stu_img` varchar(50) DEFAULT NULL,
  `sex` int(2) DEFAULT NULL,
  `level` int(3) DEFAULT NULL,
  `is_passed` int(2) NOT NULL DEFAULT '0',
  `is_locked` int(2) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  UNIQUE KEY `stu_id_UNIQUE` (`stu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_user`
-- -----------------------------
INSERT INTO `acm_user` VALUES ('1', 'user123', '123456', 'e10adc3949ba59abbe56e057f20f883e', '学生1', '2017-04-22 20:43:55', '2017-05-22 03:13:58', '12312312312', '计算机科学与技术学院', '计科1301', '2014', '333@qq.com', '1', '02aa94769a44d2275038b4a84335ac48.jpg', '1', '1', '1', '0');
INSERT INTO `acm_user` VALUES ('2', 'user111', '123456', 'e10adc3949ba59abbe56e057f20f883e', '学生2', '2017-04-27 15:48:23', '2017-05-22 03:13:58', '12341234123', '计算机科学与技术学院', '计科1301', '2017', '333@qq.com', '2', 'mystery.png', '1', '0', '1', '1');
INSERT INTO `acm_user` VALUES ('3', 'user222', '123456', 'e10adc3949ba59abbe56e057f20f883e', '学生3', '2017-04-27 15:51:33', '2017-05-22 03:13:58', '31231231231', '计算机科学与技术学院', '计科1301', '2013', '333@qq.com', '3', 'mystery.png', '1', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('4', 'user333', '123123', '4297f44b13955235245b2497399d7a93', '学生4', '2017-04-27 16:01:27', '2017-05-22 03:13:58', '12341234123', '计算机科学与技术学院', '计科1301', '2015', '333@qq.com', '5', 'mystery.png', '1', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('5', 'user444', '123456', 'e10adc3949ba59abbe56e057f20f883e', '学生5', '2017-05-04 12:52:40', '2017-05-22 03:13:58', '12312312312', '计算机科学与技术学院', '计科1301', '2014', '333@qq.com', '4', 'mystery.png', '1', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('6', 'user555', '123456', 'e10adc3949ba59abbe56e057f20f883e', '学生6', '2017-05-04 12:52:57', '2017-05-22 03:13:58', '12312312312', '计算机科学与技术学院', '计科1301', '2014', '333@qq.com', '6', 'mystery.png', '1', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('7', 'user666', '123456', 'e10adc3949ba59abbe56e057f20f883e', '学生7', '2017-05-04 12:54:51', '2017-05-22 03:13:58', '12312312312', '商学院', '计科1301', '2014', '333@qq.com', '7', 'mystery.png', '1', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('8', 'user777', '123456', 'e10adc3949ba59abbe56e057f20f883e', '学生8', '2017-05-04 12:57:34', '2017-05-22 03:13:58', '12312312312', '商学院', '计科1301', '2014', '333@qq.com', '8', 'mystery.png', '0', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('9', 'user888', '123456', 'e10adc3949ba59abbe56e057f20f883e', '学生9', '2017-05-04 23:07:39', '2017-05-22 03:13:58', '12312312312', '计算机科学与技术学院', '计科1301', '2014', '333@qq.com', '91', 'mystery.png', '0', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('10', 'user999', '123456', 'e10adc3949ba59abbe56e057f20f883e', '学生10', '2017-05-04 23:09:51', '2017-05-22 03:13:58', '12312312312', '商学院', '计科1301', '2014', '333@qq.com', '123123131222', 'mystery.png', '0', '0', '0', '0');
INSERT INTO `acm_user` VALUES ('42', 'user12345', '123456', 'e10adc3949ba59abbe56e057f20f883e', '学生112', '2017-05-25 18:27:03', '2017-05-25 18:27:03', '11111111111', '信息学院', '数学1230', '2017', '1231@qq.com', '12312312312', '__PUBLIC__/headimg/mystery.png', '1', '0', '0', '0');

-- -----------------------------
-- Table structure for `acm_user_admin`
-- -----------------------------
DROP TABLE IF EXISTS `acm_user_admin`;
CREATE TABLE `acm_user_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_id` int(11) NOT NULL,
  `clazz_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_user_admin`
-- -----------------------------
INSERT INTO `acm_user_admin` VALUES ('1', '4', '1');
INSERT INTO `acm_user_admin` VALUES ('2', '5', '2');

-- -----------------------------
-- Table structure for `acm_user_clazz`
-- -----------------------------
DROP TABLE IF EXISTS `acm_user_clazz`;
CREATE TABLE `acm_user_clazz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `clazz_id` int(11) NOT NULL,
  `check_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stu_id_UNIQUE` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_user_clazz`
-- -----------------------------
INSERT INTO `acm_user_clazz` VALUES ('1', '4', '1', '2017-01-01 00:00:00');
INSERT INTO `acm_user_clazz` VALUES ('2', '5', '2', '2017-01-01 00:00:00');
INSERT INTO `acm_user_clazz` VALUES ('3', '6', '1', '2017-01-01 00:00:00');
INSERT INTO `acm_user_clazz` VALUES ('4', '7', '1', '2017-01-01 00:00:00');
INSERT INTO `acm_user_clazz` VALUES ('5', '8', '2', '2017-01-01 00:00:00');
INSERT INTO `acm_user_clazz` VALUES ('6', '9', '1', '2017-01-01 00:00:00');
INSERT INTO `acm_user_clazz` VALUES ('7', '10', '1', '2017-01-01 00:00:00');
INSERT INTO `acm_user_clazz` VALUES ('8', '1', '1', '2017-05-22 03:34:43');
INSERT INTO `acm_user_clazz` VALUES ('9', '2', '2', '2017-05-22 03:34:56');
