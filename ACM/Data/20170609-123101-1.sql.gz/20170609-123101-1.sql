-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : acmsys
-- 
-- Part : #1
-- Date : 2017-06-09 12:31:01
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `acm_admin`
-- -----------------------------
DROP TABLE IF EXISTS `acm_admin`;
CREATE TABLE `acm_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `password_md5` varchar(40) DEFAULT NULL,
  `nickname` varchar(20) NOT NULL,
  `signUpTime` datetime DEFAULT NULL,
  `lastLoginTime` datetime DEFAULT NULL,
  `phoneNumber` varchar(45) DEFAULT '空',
  `email` varchar(50) DEFAULT '空',
  `position` varchar(45) DEFAULT '空',
  `tecentNumber` varchar(45) DEFAULT '空',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_admin`
-- -----------------------------
INSERT INTO `acm_admin` VALUES ('1', 'admin1', '123456', '202cb962ac59075b964b07152d234b70', '张三', '2017-03-10 00:00:00', '2017-06-09 03:57:56', '10000', 'admin@qq.com', '老师', '10000');
INSERT INTO `acm_admin` VALUES ('15', 'admin3', '123456', 'e10adc3949ba59abbe56e057f20f883e', '张三', '2017-05-12 20:53:27', '2017-05-12 20:53:27', '10000', 'admin@qq.com', '老师', '10000');
INSERT INTO `acm_admin` VALUES ('16', 'admin4', '123456', 'e10adc3949ba59abbe56e057f20f883e', '张三', '2017-05-12 20:53:38', '2017-05-12 20:53:38', '10000', 'admin@qq.com', '老师', '10000');

-- -----------------------------
-- Table structure for `acm_check_clazz`
-- -----------------------------
DROP TABLE IF EXISTS `acm_check_clazz`;
CREATE TABLE `acm_check_clazz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_clazz` int(11) NOT NULL,
  `id_stu` int(11) NOT NULL,
  `checktime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stu_idx` (`id_stu`),
  KEY `clazz_idx` (`id_clazz`),
  CONSTRAINT `clazz` FOREIGN KEY (`id_clazz`) REFERENCES `acm_clazz` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `stu` FOREIGN KEY (`id_stu`) REFERENCES `acm_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_check_clazz`
-- -----------------------------
INSERT INTO `acm_check_clazz` VALUES ('8', '3', '3', '2017-06-09 03:27:04');
INSERT INTO `acm_check_clazz` VALUES ('9', '2', '43', '2017-06-09 03:33:49');

-- -----------------------------
-- Table structure for `acm_clazz`
-- -----------------------------
DROP TABLE IF EXISTS `acm_clazz`;
CREATE TABLE `acm_clazz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clazzname` varchar(45) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `tutor` int(11) DEFAULT NULL,
  `last_time_modify` datetime DEFAULT NULL,
  `clazz_info` varchar(255) DEFAULT NULL,
  `grade` int(11) DEFAULT NULL,
  `level` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_clazz`
-- -----------------------------
INSERT INTO `acm_clazz` VALUES ('1', 'ACM-A', '2017-05-20 00:00:00', '1', '2017-05-20 00:00:00', '16级学生ACM兴趣班', '2016', '2');
INSERT INTO `acm_clazz` VALUES ('2', 'ACM-S', '2017-05-19 00:00:00', '1', '2017-05-19 00:00:00', '17级学生ACM兴趣班', '2017', '1');
INSERT INTO `acm_clazz` VALUES ('3', 'ACM-M', '2017-06-09 00:00:00', '1', '2017-06-09 00:00:00', '13级ACM初级兴趣班', '2013', '1');

-- -----------------------------
-- Table structure for `acm_clazz_work`
-- -----------------------------
DROP TABLE IF EXISTS `acm_clazz_work`;
CREATE TABLE `acm_clazz_work` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `workcontent` varchar(45) DEFAULT '空',
  `createtime` datetime DEFAULT NULL,
  `clazz_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_clazz_work`
-- -----------------------------
INSERT INTO `acm_clazz_work` VALUES ('1', '本周五（20号）下午开会', '2017-05-16 14:38:48', '1');
INSERT INTO `acm_clazz_work` VALUES ('4', '本周五（20号）五下午开会', '2017-05-16 14:50:02', '2');
INSERT INTO `acm_clazz_work` VALUES ('5', '事务内容', '2017-06-09 02:08:19', '3');

-- -----------------------------
-- Table structure for `acm_inform`
-- -----------------------------
DROP TABLE IF EXISTS `acm_inform`;
CREATE TABLE `acm_inform` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL DEFAULT '空',
  `datetime` datetime NOT NULL,
  `content` varchar(45) NOT NULL DEFAULT '暂时无通知',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_inform`
-- -----------------------------
INSERT INTO `acm_inform` VALUES ('1', '关于申请班级事项', '2017-03-22 00:22:33', '通过注册审核后，请尽快申请加入班级');

-- -----------------------------
-- Table structure for `acm_todaylogin`
-- -----------------------------
DROP TABLE IF EXISTS `acm_todaylogin`;
CREATE TABLE `acm_todaylogin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_todaylogin`
-- -----------------------------
INSERT INTO `acm_todaylogin` VALUES ('3', '2017-05-15 20:48:54');
INSERT INTO `acm_todaylogin` VALUES ('4', '2017-05-16 17:36:09');
INSERT INTO `acm_todaylogin` VALUES ('5', '2017-05-16 17:53:23');
INSERT INTO `acm_todaylogin` VALUES ('6', '2017-05-19 02:37:49');
INSERT INTO `acm_todaylogin` VALUES ('7', '2017-05-19 14:25:51');
INSERT INTO `acm_todaylogin` VALUES ('8', '2017-05-19 15:52:00');
INSERT INTO `acm_todaylogin` VALUES ('9', '2017-05-20 01:25:17');
INSERT INTO `acm_todaylogin` VALUES ('10', '2017-05-22 03:13:58');
INSERT INTO `acm_todaylogin` VALUES ('11', '2017-05-25 18:57:48');
INSERT INTO `acm_todaylogin` VALUES ('12', '2017-05-25 19:23:38');
INSERT INTO `acm_todaylogin` VALUES ('13', '2017-05-25 19:35:11');
INSERT INTO `acm_todaylogin` VALUES ('14', '2017-05-25 20:09:47');
INSERT INTO `acm_todaylogin` VALUES ('15', '2017-05-25 20:11:47');
INSERT INTO `acm_todaylogin` VALUES ('16', '2017-05-25 23:20:14');
INSERT INTO `acm_todaylogin` VALUES ('17', '2017-05-25 23:40:01');
INSERT INTO `acm_todaylogin` VALUES ('18', '2017-05-26 01:42:40');
INSERT INTO `acm_todaylogin` VALUES ('19', '2017-05-26 13:20:37');
INSERT INTO `acm_todaylogin` VALUES ('20', '2017-05-30 15:47:11');
INSERT INTO `acm_todaylogin` VALUES ('21', '2017-05-31 11:07:17');
INSERT INTO `acm_todaylogin` VALUES ('22', '2017-05-31 12:05:46');
INSERT INTO `acm_todaylogin` VALUES ('23', '2017-05-31 12:35:20');
INSERT INTO `acm_todaylogin` VALUES ('24', '2017-05-31 12:35:40');
INSERT INTO `acm_todaylogin` VALUES ('25', '2017-06-08 00:25:31');
INSERT INTO `acm_todaylogin` VALUES ('26', '2017-06-09 02:19:42');
INSERT INTO `acm_todaylogin` VALUES ('27', '2017-06-09 03:31:13');
INSERT INTO `acm_todaylogin` VALUES ('28', '2017-06-09 03:55:04');

-- -----------------------------
-- Table structure for `acm_user`
-- -----------------------------
DROP TABLE IF EXISTS `acm_user`;
CREATE TABLE `acm_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(18) NOT NULL,
  `password` varchar(20) NOT NULL,
  `md5pwd` varchar(45) DEFAULT NULL,
  `nickname` varchar(20) NOT NULL,
  `sign_up_time` datetime DEFAULT NULL,
  `last_login_time` datetime DEFAULT NULL,
  `phonenumber` varchar(11) DEFAULT NULL,
  `institude` varchar(10) DEFAULT NULL,
  `class` varchar(15) DEFAULT NULL,
  `grade` int(3) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `stu_id` varchar(12) NOT NULL,
  `stu_img` varchar(50) DEFAULT NULL,
  `sex` int(2) DEFAULT NULL,
  `level` int(3) DEFAULT NULL,
  `is_passed` int(2) NOT NULL DEFAULT '0',
  `is_locked` int(2) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  UNIQUE KEY `stu_id_UNIQUE` (`stu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_user`
-- -----------------------------
INSERT INTO `acm_user` VALUES ('1', 'user123', '123456', 'e10adc3949ba59abbe56e057f20f883e', '腾兴业', '2017-04-22 20:43:55', '2017-06-08 00:25:31', '20172231442', '计算机科学与技术学院', '计科1301', '2014', '333@qq.com', '123', 'e6b39bdb91c7bf1e3010ccef10ea864c.jpg', '1', '0', '1', '1');
INSERT INTO `acm_user` VALUES ('2', 'user111', '123456', 'e10adc3949ba59abbe56e057f20f883e', '侯天干', '2017-04-27 15:48:23', '2017-05-22 03:13:58', '12341234123', '计算机科学与技术学院', '计科1301', '2017', '333@qq.com', '2', 'mystery.png', '1', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('3', 'user222', '123456', 'e10adc3949ba59abbe56e057f20f883e', '杜霞', '2017-04-27 15:51:33', '2017-06-09 02:19:42', '1231', '计算机科学与技术1', '计科1301', '2013', '333@qq.com', '32', 'aad2187eaa24034835871ede49410e1a.jpg', '2', '1', '1', '0');
INSERT INTO `acm_user` VALUES ('4', 'user333', '123123', '4297f44b13955235245b2497399d7a93', '平孟阳', '2017-04-27 16:01:27', '2017-05-22 03:13:58', '12341234123', '计算机科学与技术学院', '计科1301', '2015', '333@qq.com', '5', 'mystery.png', '1', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('5', 'user444', '123456', 'e10adc3949ba59abbe56e057f20f883e', '匡碧菡', '2017-05-04 12:52:40', '2017-05-22 03:13:58', '12312312312', '计算机科学与技术学院', '计科1301', '2014', '333@qq.com', '4', 'mystery.png', '1', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('6', 'user555', '123456', 'e10adc3949ba59abbe56e057f20f883e', '区嘉歆', '2017-05-04 12:52:57', '2017-05-25 23:40:01', '12312312312', '计算机科学与技术学院', '计科1301', '2014', '333@qq.com', '6', 'mystery.png', '1', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('7', 'user666', '123456', 'e10adc3949ba59abbe56e057f20f883e', '庄新冬', '2017-05-04 12:54:51', '2017-05-31 12:35:20', '12312312312', '商学院', '计科1301', '2014', '333@qq.com', '7', 'eb543a1a8ebb21d2e7438995d48a0dec.jpg', '1', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('8', 'user777', '123456', 'e10adc3949ba59abbe56e057f20f883e', '考震轩', '2017-05-04 12:57:34', '2017-05-31 12:35:40', '12312312312', '商学院', '计科1301', '2014', '333@qq.com', '8', 'mystery.png', '0', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('9', 'user888', '123456', 'e10adc3949ba59abbe56e057f20f883e', '叶若云', '2017-05-04 23:07:39', '2017-05-30 15:47:11', '12312312312', '计算机科学与技术学院', '计科1301', '2014', '333@qq.com', '91', 'mystery.png', '0', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('10', 'user999', '123456', 'e10adc3949ba59abbe56e057f20f883e', '季书双', '2017-05-04 23:09:51', '2017-05-22 03:13:58', '12312312312', '商学院', '计科1301', '2014', '333@qq.com', '123123131222', 'mystery.png', '0', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('42', 'user12345', '123456', 'e10adc3949ba59abbe56e057f20f883e', '储齐心', '2017-05-25 18:27:03', '2017-05-25 18:27:03', '11111111111', '数学学院', '数学1230', '2017', '1231@qq.com', '12312312312', 'mystery.png', '1', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('43', 'wjc123', '123456', 'e10adc3949ba59abbe56e057f20f883e', 'Seong', '2017-06-09 03:29:50', '2017-06-09 03:55:04', '123123', '信息学院', '揭开1203', '2017', '123123@qq.com', '123123123', '7f040c30711b2daed56185d5421ff77f.jpg', '0', '0', '1', '0');
INSERT INTO `acm_user` VALUES ('48', 'wjc111', '123456', 'e10adc3949ba59abbe56e057f20f883e', 'Seong', '2017-06-09 03:53:59', '2017-06-09 03:53:59', '123', '计算机', '计科1301', '2013', '123@qq.com', '123123123123', 'mystery.png', '0', '0', '1', '0');

-- -----------------------------
-- Table structure for `acm_user_admin`
-- -----------------------------
DROP TABLE IF EXISTS `acm_user_admin`;
CREATE TABLE `acm_user_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_id` int(11) NOT NULL,
  `clazz_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_user_admin`
-- -----------------------------
INSERT INTO `acm_user_admin` VALUES ('3', '3', '1');

-- -----------------------------
-- Table structure for `acm_user_clazz`
-- -----------------------------
DROP TABLE IF EXISTS `acm_user_clazz`;
CREATE TABLE `acm_user_clazz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `clazz_id` int(11) NOT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  `check_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stu_id_UNIQUE` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `acm_user_clazz`
-- -----------------------------
INSERT INTO `acm_user_clazz` VALUES ('12', '1', '1', '1', '2017-05-25 20:04:57');
INSERT INTO `acm_user_clazz` VALUES ('13', '7', '2', '1', '2017-06-08 14:28:20');
INSERT INTO `acm_user_clazz` VALUES ('14', '8', '1', '1', '2017-06-09 02:09:05');
